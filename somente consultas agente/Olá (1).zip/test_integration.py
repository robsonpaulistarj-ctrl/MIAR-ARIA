"""
Teste automatizado: lança o servidor e o cliente em paralelo
para validar a integração WebSocket.
"""
import asyncio
import json
import sys

import uvicorn
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware

import websockets


# ── Servidor (idêntico ao server.py) ──
app = FastAPI()
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


@app.websocket("/ws")
async def ws_endpoint(ws: WebSocket):
    await ws.accept()
    await ws.send_json({"type": "status", "text": "Ligado ao servidor. Pronto para receber tarefas."})
    try:
        while True:
            data = await ws.receive_json()
            if data.get("type") == "task":
                await asyncio.sleep(0.5)
                await ws.send_json({
                    "type": "response",
                    "text": f"Tarefa '{data['text']}' processada com sucesso!",
                })
            elif data.get("type") == "ping":
                await ws.send_json({"type": "pong", "ts": asyncio.get_event_loop().time()})
    except WebSocketDisconnect:
        pass


# ── Teste ──
async def run_test():
    # Iniciar servidor em background
    config = uvicorn.Config(app, host="127.0.0.1", port=8765, log_level="error")
    server = uvicorn.Server(config)
    task = asyncio.create_task(server.serve())
    while not server.started:
        await asyncio.sleep(0.05)

    print("🧪 A testar integração WebSocket...\n")

    async with websockets.connect("ws://127.0.0.1:8765/ws") as ws:
        # 1. Boas-vindas
        welcome = json.loads(await ws.recv())
        assert welcome["type"] == "status", "deveria receber status"
        print(f"✓ Mensagem de boas-vindas recebida: {welcome['text']}")

        # 2. Enviar tarefa
        await ws.send(json.dumps({"type": "task", "text": "Teste automático"}))
        resp = json.loads(await ws.recv())
        assert resp["type"] == "response", "deveria receber response"
        print(f"✓ Tarefa processada: {resp['text']}")

        # 3. Ping/Pong
        await ws.send(json.dumps({"type": "ping"}))
        pong = json.loads(await ws.recv())
        assert pong["type"] == "pong", "deveria receber pong"
        print(f"✓ Ping/Pong OK (ts={pong['ts']:.2f})")

        # 4. Múltiplas tarefas rápidas
        for i in range(5):
            await ws.send(json.dumps({"type": "task", "text": f"Tarefa {i}"}))
            r = json.loads(await ws.recv())
            assert r["type"] == "response"
        print("✓ 5 tarefas consecutivas processadas sem erros")

    print("\n✅ TODOS OS TESTES PASSARAM — integração WebSocket funcional!\n")
    server.should_exit = True
    await task


if __name__ == "__main__":
    asyncio.run(run_test())
