"""
═══════════════════════════════════════════════════════════════════════════════
 SERVIDOR WEBSOCKET — Backend Python (integração com Electron)
═══════════════════════════════════════════════════════════════════════════════

 Este servidor FastAPI cria um endpoint WebSocket em /ws que permite ao
 Electron (ou a qualquer cliente) trocar mensagens bidirecionais em tempo real.

 Tipos de mensagem suportados:
   Cliente → Servidor:  {"type": "task", "text": "..."}   (enviar tarefa)
                        {"type": "ping"}                   (heartbeat)
   Servidor → Cliente:  {"type": "response", "text": "..."}
                        {"type": "status", "text": "ok"}
                        {"type": "pong", "ts": ...}

 Executar:
   pip install fastapi "uvicorn[standard]" websockets
   python server.py
"""

import asyncio
import json
import time
from contextlib import asynccontextmanager

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware


# ---------------------------------------------------------------------------
# FastAPI App
# ---------------------------------------------------------------------------
@asynccontextmanager
async def lifespan(app: FastAPI):
    yield


app = FastAPI(title="Electron WebSocket Server")

# CORS para permitir ligações de qualquer origem (útil em desenvolvimento)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Registo de clientes ligados (para broadcast, se necessário)
_clients: set = set()


# ---------------------------------------------------------------------------
# WebSocket Endpoint
# ---------------------------------------------------------------------------
@app.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):
    """
    Aceita ligações de clientes (Electron renderer, scripts Python, etc.)
    e mantém a ligação aberta para comunicação bidirecional.
    """
    await ws.accept()
    _clients.add(ws)
    client_addr = ws.client
    print(f"[+] Cliente ligado: {client_addr.host}:{client_addr.port}")

    try:
        # Enviar mensagem de boas-vindas
        await ws.send_json({"type": "status", "text": "Ligado ao servidor. Pronto para receber tarefas."})

        # Loop principal — escutar mensagens do cliente indefinidamente
        while True:
            # receber_json() lê um objeto JSON do cliente
            data = await ws.receive_json()
            msg_type = data.get("type", "")
            msg_text = data.get("text", "")

            print(f"← Recebido: {data}")

            if msg_type == "task":
                # ── Processar uma tarefa ──
                # Aqui podes chamar qualquer função do teu backend
                result = await process_task(msg_text)

                # Enviar resposta ao cliente
                await ws.send_json({
                    "type": "response",
                    "text": result,
                    "ts": time.time(),
                })

            elif msg_type == "ping":
                # ── Heartbeat / keep-alive ──
                await ws.send_json({"type": "pong", "ts": time.time()})

            else:
                await ws.send_json({
                    "type": "error",
                    "text": f"Tipo de mensagem desconhecido: {msg_type}",
                })

    except WebSocketDisconnect:
        print(f"[-] Cliente desligado: {client_addr.host}:{client_addr.port}")
    except Exception as e:
        print(f"[!] Erro na ligação: {e}")
    finally:
        _clients.discard(ws)


# ---------------------------------------------------------------------------
# Função de exemplo — processa a tarefa recebida
# ---------------------------------------------------------------------------
async def process_task(task_text: str) -> str:
    """
    Simula o processamento de uma tarefa. Substitui pela tua lógica real:
    chamadas a APIs, manipulação de ficheiros, Playwright, etc.
    """
    await asyncio.sleep(1)  # simula trabalho assíncrono
    return f"Tarefa '{task_text}' processada com sucesso! (echo do servidor)"


# ---------------------------------------------------------------------------
# Broadcast (opcional) — enviar para todos os clientes
# ---------------------------------------------------------------------------
async def broadcast(message: dict):
    """Envia a mesma mensagem para todos os clientes ligados."""
    for ws in list(_clients):
        try:
            await ws.send_json(message)
        except Exception:
            _clients.discard(ws)


# ---------------------------------------------------------------------------
# Endpoint HTTP de saúde (opcional)
# ---------------------------------------------------------------------------
@app.get("/")
async def root():
    return {
        "service": "Electron WebSocket Server",
        "status": "online",
        "clients_connected": len(_clients),
        "ws_url": "ws://localhost:8000/ws",
    }


# ---------------------------------------------------------------------------
# Iniciar servidor
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import uvicorn

    PORT = 8000
    print(f"🚀 Servidor WebSocket a correr em http://localhost:{PORT}")
    print(f"   WebSocket: ws://localhost:{PORT}/ws")
    uvicorn.run(app, host="0.0.0.0", port=PORT)
