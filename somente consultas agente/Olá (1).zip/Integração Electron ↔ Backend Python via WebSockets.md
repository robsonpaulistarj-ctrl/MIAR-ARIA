# Integração Electron ↔ Backend Python via WebSockets

Este projeto demonstra, de forma completa e testada, como integrar uma aplicação **Electron** com um **backend Python** usando **WebSockets** para comunicação bidirecional em tempo real.

## Estrutura dos Ficheiros

| Ficheiro | Descrição |
|---|---|
| `server.py` | Servidor WebSocket (FastAPI) — recebe tarefas do Electron e envia respostas |
| `client.py` | Cliente Python que simula o comportamento do Electron (renderer.js) |
| `electron_renderer_example.js` | Código JavaScript pronto a colar no teu `renderer.js` no Electron |
| `test_integration.py` | Teste automatizado que valida toda a comunicação |

## Como Funciona

O padrão de comunicação é o seguinte:

```
┌─────────────────────┐                    ┌──────────────────────┐
│      Electron        │                    │   Backend Python      │
│  (renderer.js)       │                    │   (FastAPI + WS)      │
│                      │   {"type":"task"}  │                      │
│  ws.send(JSON)  ────►│ ─────────────────► │  receive_json()      │
│                      │                    │       ↓               │
│  ws.onmessage() ◄────│ ◄───────────────── │  process_task()      │
│  {"type":"response"} │   {"type":"response"}                      │
└─────────────────────┘                    └──────────────────────┘
```

## Como Executar

### 1. Instalar dependências

```bash
pip install fastapi "uvicorn[standard]" websockets
```

### 2. Iniciar o servidor

```bash
python server.py
# → Servidor WebSocket a correr em http://localhost:8000
#   WebSocket: ws://localhost:8000/ws
```

### 3. (Opcional) Testar com o cliente Python

```bash
python client.py
```

### 4. (Opcional) Teste automatizado

```bash
python test_integration.py
```

### 5. Usar no Electron

Cola o conteúdo de `electron_renderer_example.js` no teu `renderer.js` e ajusta os IDs dos elementos do DOM.

## Protocolo de Mensagens

### Cliente → Servidor

| Tipo | Estrutura | Descrição |
|---|---|---|
| `task` | `{"type": "task", "text": "..."}` | Enviar uma tarefa para processamento |
| `ping` | `{"type": "ping"}` | Heartbeat para manter a ligação ativa |

### Servidor → Cliente

| Tipo | Estrutura | Descrição |
|---|---|---|
| `status` | `{"type": "status", "text": "..."}` | Mensagem de estado/boas-vindas |
| `response` | `{"type": "response", "text": "..."}` | Resultado do processamento de uma tarefa |
| `pong` | `{"type": "pong", "ts": 1234567890}` | Resposta ao heartbeat |
| `error` | `{"type": "error", "text": "..."}` | Erro de mensagem inválida |

## Código Equivalente (Python ↔ JavaScript)

### Python (client.py)

```python
import websockets, json, asyncio

async with websockets.connect("ws://localhost:8000/ws") as ws:
    # Enviar
    await ws.send(json.dumps({"type": "task", "text": "minha tarefa"}))
    # Receber
    msg = json.loads(await ws.recv())
    print(msg["text"])
```

### JavaScript (renderer.js no Electron)

```javascript
const ws = new WebSocket("ws://localhost:8000/ws");

// Enviar
ws.send(JSON.stringify({type: "task", text: "minha tarefa"}));

// Receber
ws.onmessage = (ev) => {
    const msg = JSON.parse(ev.data);
    console.log(msg.text);
};
```

## Personalização

### No servidor (server.py)

Para integrar com a tua lógica real, substitui o corpo da função `process_task()`:

```python
async def process_task(task_text: str) -> str:
    # Exemplo: chamar uma API externa
    # response = requests.get(f"https://api.exemplo.com?q={task_text}")
    # return response.json()["result"]

    # Exemplo: chamar o Playwright
    # async with async_playwright() as p:
    #     browser = await p.chromium.launch()
    #     ...

    return f"Resultado de: {task_text}"
```

### Broadcast para múltiplos clientes

O servidor já mantém um registo de `_clients`. Para enviar uma mensagem a todos os clientes ligados simultaneamente:

```python
await broadcast({"type": "notification", "text": "Evento para todos!"})
```

## Notas Técnicas

- O servidor usa **FastAPI** com o decorador `@app.websocket()` — não é necessário um pacote WebSocket separado.
- A reconexão automática no cliente é tratada com `setTimeout(connect, 3000)` após `onclose`.
- O **heartbeat** (ping/pong a cada 30s) previne que firewalls/proxies fechem ligações inativas.
- O CORS está configurado para `allow_origins=["*"]` — em produção, restringe ao domínio do teu Electron.
