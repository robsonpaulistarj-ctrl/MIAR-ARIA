/*
═══════════════════════════════════════════════════════════════════════════════
 RENDERER.JS — Código para colar no teu projeto Electron
═══════════════════════════════════════════════════════════════════════════════

 Este é o equivalente em JavaScript do client.py acima.
 Cola este código no teu renderer.js (ou index.html <script>) no Electron.
*/

// ── Configuração ──
const WS_URL = "ws://localhost:8000/ws";

// ── Elementos do DOM (ajusta os IDs conforme o teu HTML) ──
const statusEl = document.getElementById("status");
const logEl = document.getElementById("log");
const inputEl = document.getElementById("task-input");
const btnEl = document.getElementById("btn-send");

// ── WebSocket ──
let ws = null;

function connect() {
  ws = new WebSocket(WS_URL);

  ws.onopen = () => {
    console.log("✅ Ligado ao servidor WebSocket");
    if (statusEl) statusEl.textContent = "Ligado";
  };

  ws.onmessage = (event) => {
    const msg = JSON.parse(event.data);
    console.log("← Servidor:", msg);

    // Atualizar UI conforme o tipo de mensagem
    switch (msg.type) {
      case "status":
        if (statusEl) statusEl.textContent = msg.text;
        break;

      case "response":
        if (logEl) {
          const entry = document.createElement("div");
          entry.textContent = `[${new Date().toLocaleTimeString()}] ${msg.text}`;
          logEl.appendChild(entry);
          logEl.scrollTop = logEl.scrollHeight;
        }
        break;

      case "pong":
        console.log("🏓 Pong recebido — ligação ativa");
        break;

      case "error":
        console.error("❌ Erro:", msg.text);
        break;
    }
  };

  ws.onclose = () => {
    console.log("🔌 Desligado — a tentar religar em 3s...");
    if (statusEl) statusEl.textContent = "Desligado";
    setTimeout(connect, 3000); // reconexão automática
  };

  ws.onerror = (err) => {
    console.error("Erro WebSocket:", err);
    ws.close();
  };
}

// ── Enviar tarefa ──
function sendTask(text) {
  if (ws && ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify({ type: "task", text: text }));
    console.log("→ Enviado:", text);
  } else {
    console.warn("⚠️ WebSocket não está ligado!");
  }
}

// ── Heartbeat a cada 30 segundos ──
function startHeartbeat() {
  setInterval(() => {
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type: "ping" }));
    }
  }, 30000);
}

// ── Event Listeners ──
if (btnEl) {
  btnEl.addEventListener("click", () => {
    const text = inputEl ? inputEl.value.trim() : "";
    if (text) sendTask(text);
  });
}

// ── Iniciar ──
connect();
startHeartbeat();

// Exportar para uso global (opcional)
window.sendTask = sendTask;
