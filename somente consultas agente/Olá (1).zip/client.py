"""
═══════════════════════════════════════════════════════════════════════════════
 CLIENTE WEBSOCKET — Simula o Electron (renderer.js) em Python
═══════════════════════════════════════════════════════════════════════════════

 Este script demonstra como o lado do Electron se liga ao servidor WebSocket
 e troca mensagens. Podes usar isto como referência para o teu renderer.js.

 No Electron, o equivalente seria (em renderer.js):
   const ws = new WebSocket("ws://localhost:8000/ws");
   ws.onmessage = (ev) => { const msg = JSON.parse(ev.data); ... }
   ws.send(JSON.stringify({type: "task", text: "minha tarefa"}));

 Executar (depois de iniciar o server.py):
   pip install websockets
   python client.py
"""

import asyncio
import json
import time

import websockets

WS_URL = "ws://localhost:8000/ws"


async def main():
    print(f"🔌 A ligar a {WS_URL}...")

    async with websockets.connect(WS_URL) as ws:
        print("✅ Ligado ao servidor!\n")

        # ── 1. Receber mensagem de boas-vindas ──
        welcome = await ws.recv()
        msg = json.loads(welcome)
        print(f"← Servidor: {msg}\n")

        # ── 2. Enviar uma tarefa ──
        task = "Pesquisar preço do Bitcoin"
        print(f"→ Enviar tarefa: {task}")
        await ws.send(json.dumps({"type": "task", "text": task}))

        # ── 3. Receber resposta ──
        response = await ws.recv()
        msg = json.loads(response)
        print(f"← Resposta: {msg['text']}\n")

        # ── 4. Heartbeat (ping/pong) ──
        print("→ Enviar ping...")
        await ws.send(json.dumps({"type": "ping"}))
        pong = await ws.recv()
        msg = json.loads(pong)
        print(f"← Pong recebido (ts={msg.get('ts')})\n")

        # ── 5. Enviar outra tarefa ──
        task2 = "Verificar estado do sistema"
        print(f"→ Enviar tarefa: {task2}")
        await ws.send(json.dumps({"type": "task", "text": task2}))
        response2 = await ws.recv()
        msg2 = json.loads(response2)
        print(f"← Resposta: {msg2['text']}\n")

        print("🏁 Cliente a desligar...")


if __name__ == "__main__":
    asyncio.run(main())
